package com.example.demo.enums;

public enum AptStatus {

	BOOKED,
	CONFIRMED,
	CANCELLED,
	CLOSED
	
}
